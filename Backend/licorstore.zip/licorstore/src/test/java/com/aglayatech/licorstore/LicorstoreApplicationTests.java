package com.aglayatech.licorstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicorstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
