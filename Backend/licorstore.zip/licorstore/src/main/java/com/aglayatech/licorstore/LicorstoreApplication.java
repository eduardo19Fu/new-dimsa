package com.aglayatech.licorstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LicorstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(LicorstoreApplication.class, args);
	}

}
